///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"

// GLFW library
#include "GLFW/glfw3.h" 

class ViewManager
{
public:
    // ctor / dtor
    ViewManager(ShaderManager* pShaderManager);
    ~ViewManager();

    // GLFW static callbacks
    static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);
    static void Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset);

private:
    // pointer members
    ShaderManager* m_pShaderManager;
    GLFWwindow* m_pWindow;

    // internal
    void ProcessKeyboardEvents();

public:
    // window + per-frame prep
    GLFWwindow* CreateDisplayWindow(const char* windowTitle);
    void PrepareSceneView();

    // === methods MainCode.cpp calls (ONE declaration each) ===
    void SetProjectionModePerspective();
    void SetProjectionModeOrthographic();

    void MoveForward(float dt);
    void MoveBackward(float dt);
    void MoveLeft(float dt);
    void MoveRight(float dt);
    void MoveUp(float dt);
    void MoveDown(float dt);

    // Optional wrappers (harmless if unused)
    void OnMouseMove(double xpos, double ypos);
    void OnScroll(double yoffset);
};