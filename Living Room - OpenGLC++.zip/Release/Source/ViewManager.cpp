///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
    // Variables for window width and height
    const int WINDOW_WIDTH = 1000;
    const int WINDOW_HEIGHT = 800;
    const char* g_ViewName = "view";
    const char* g_ProjectionName = "projection";

    // camera object used for viewing and interacting with the 3D scene
    Camera* g_pCamera = nullptr;

    // mouse state
    float gLastX = WINDOW_WIDTH * 0.5f;
    float gLastY = WINDOW_HEIGHT * 0.5f;
    bool  gFirstMouse = true;

    // time between current frame and last frame
    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    // orthographic toggle
    bool bOrthographicProjection = false;

    // movement speed (units/sec) � adjusted by mouse wheel
    float gMoveSpeed = 3.0f;          // <-- keep ONLY this one
}

/***********************************************************
 *  ViewManager()
 ***********************************************************/
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_pWindow = NULL;

    g_pCamera = new Camera();
    // default camera view parameters
    g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
    g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
    g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
    g_pCamera->Zoom = 80.0f;
}

/***********************************************************
 *  ~ViewManager()
 ***********************************************************/
ViewManager::~ViewManager()
{
    m_pShaderManager = NULL;
    m_pWindow = NULL;
    if (NULL != g_pCamera)
    {
        delete g_pCamera;
        g_pCamera = NULL;
    }
}

/***********************************************************
 *  CreateDisplayWindow()
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return NULL;
    }
    glfwMakeContextCurrent(window);

    // tell GLFW to capture all mouse events (optional FPS-style)
    // glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // callbacks (OK if also set from MainCode.cpp)
    glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
    glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);  // <-- add scroll

    // enable blending for supporting transparent rendering
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_pWindow = window;
    return window;
}

/***********************************************************
 *  Mouse_Position_Callback()
 *  Called from GLFW whenever the mouse moves.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* /*window*/, double xMousePos, double yMousePos)
{
    if (!g_pCamera) return;

    if (gFirstMouse) {
        gLastX = static_cast<float>(xMousePos);
        gLastY = static_cast<float>(yMousePos);
        gFirstMouse = false;
        return;
    }

    float xoffset = static_cast<float>(xMousePos) - gLastX;
    float yoffset = gLastY - static_cast<float>(yMousePos);  // reversed: screen y grows down
    gLastX = static_cast<float>(xMousePos);
    gLastY = static_cast<float>(yMousePos);

    g_pCamera->ProcessMouseMovement(xoffset, yoffset);
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *  Adjust movement speed with the scroll wheel.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* /*window*/, double /*xOffset*/, double yOffset)
{
    gMoveSpeed += static_cast<float>(yOffset) * 0.5f;
    if (gMoveSpeed < 0.5f)  gMoveSpeed = 0.5f;
    if (gMoveSpeed > 20.0f) gMoveSpeed = 20.0f;
}

/***********************************************************
 *  Optional instance wrappers (used by MainCode.cpp)
 ***********************************************************/
void ViewManager::OnMouseMove(double xpos, double ypos) { Mouse_Position_Callback(nullptr, xpos, ypos); }
void ViewManager::OnScroll(double yoffset) { Mouse_Scroll_Callback(nullptr, 0.0, yoffset); }

/***********************************************************
 *  Movement helpers (used by MainCode.cpp)
 ***********************************************************/
void ViewManager::MoveForward(float dt) {
    if (!g_pCamera) return;
    g_pCamera->Position += glm::normalize(g_pCamera->Front) * (gMoveSpeed * dt);
}
void ViewManager::MoveBackward(float dt) {
    if (!g_pCamera) return;
    g_pCamera->Position -= glm::normalize(g_pCamera->Front) * (gMoveSpeed * dt);
}
void ViewManager::MoveLeft(float dt) {
    if (!g_pCamera) return;
    glm::vec3 right = glm::normalize(glm::cross(g_pCamera->Front, g_pCamera->Up));
    g_pCamera->Position -= right * (gMoveSpeed * dt);
}
void ViewManager::MoveRight(float dt) {
    if (!g_pCamera) return;
    glm::vec3 right = glm::normalize(glm::cross(g_pCamera->Front, g_pCamera->Up));
    g_pCamera->Position += right * (gMoveSpeed * dt);
}
void ViewManager::MoveUp(float dt) {
    if (!g_pCamera) return;
    g_pCamera->Position += glm::normalize(g_pCamera->Up) * (gMoveSpeed * dt);
}
void ViewManager::MoveDown(float dt) {
    if (!g_pCamera) return;
    g_pCamera->Position -= glm::normalize(g_pCamera->Up) * (gMoveSpeed * dt);
}

/***********************************************************
 *  Projection toggles (used by MainCode.cpp)
 ***********************************************************/
void ViewManager::SetProjectionModePerspective() { bOrthographicProjection = false; }
void ViewManager::SetProjectionModeOrthographic() { bOrthographicProjection = true; }

/***********************************************************
 *  ProcessKeyboardEvents()  � keep minimal (ESC only)
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
    if (!m_pWindow) return;

    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(m_pWindow, true);
}

/***********************************************************
 *  PrepareSceneView()
 *  Builds view/projection matrices and sends them to the shader.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
    glm::mat4 view;
    glm::mat4 projection;

    // per-frame timing
    float currentFrame = static_cast<float>(glfwGetTime());
    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;

    // ESC handling (movement handled in MainCode.cpp)
    ProcessKeyboardEvents();

    // VIEW
    if (bOrthographicProjection) {
        // Look straight at the scene; keep the floor (y=0) out of frame.
        glm::vec3 eye = glm::vec3(0.0f, 2.0f, 8.0f);
        glm::vec3 target = glm::vec3(0.0f, 2.0f, 0.0f);
        glm::vec3 up = glm::vec3(0.0f, 1.0f, 0.0f);
        view = glm::lookAt(eye, target, up);
    }
    else {
        view = g_pCamera->GetViewMatrix();
    }

    // PROJECTION
    const float aspect = static_cast<float>(WINDOW_WIDTH) / static_cast<float>(WINDOW_HEIGHT);
    if (bOrthographicProjection) {
        const float halfH = 4.0f;
        const float halfW = halfH * aspect;
        projection = glm::ortho(-halfW, halfW, -halfH, halfH, 0.1f, 100.0f);
    }
    else {
        projection = glm::perspective(glm::radians(g_pCamera->Zoom), aspect, 0.1f, 100.0f);
    }

    // Send to shader
    if (m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ViewName, view);
        m_pShaderManager->setMat4Value(g_ProjectionName, projection);
        m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
    }
}
