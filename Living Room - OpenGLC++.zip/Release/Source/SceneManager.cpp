﻿///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
	static GLuint gTexFabric = 0;   // couch cushions
	static GLuint gTexWood = 0;   // couch frame/legs
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].ID != 0) {
			glDeleteTextures(1, &m_textureIDs[i].ID);  // delete, not generate
			m_textureIDs[i].ID = 0;
		}
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

void SceneManager::LoadSceneTextures()
{
	// Make sure stb flips images (most course textures need it)
	stbi_set_flip_vertically_on_load(1);

	
	bool okFabric = CreateGLTexture("Assets\\Textures\\fabric.jpg", "fabric");
	bool okWood = CreateGLTexture("Assets\\Textures\\wood.jpg", "wood");

	std::cout << "[Textures] fabric: " << (okFabric ? "OK" : "FAIL") << "\n";
	std::cout << "[Textures] wood:   " << (okWood ? "OK" : "FAIL") << "\n";

	
	BindGLTextures();

	
	int idFabric = FindTextureID("fabric");     // GL id (e.g., 7, 9, …)
	int idWood = FindTextureID("wood");
	int slotFabric = FindTextureSlot("fabric");   // texture unit index (0,1,…)
	int slotWood = FindTextureSlot("wood");

	std::cout << "[IDs]   fabric=" << idFabric << " wood=" << idWood << "\n";
	std::cout << "[Slots] fabric=" << slotFabric << " wood=" << slotWood << "\n";


	gTexFabric = (idFabric > 0) ? (GLuint)idFabric : 0;
	gTexWood = (idWood > 0) ? (GLuint)idWood : 0;
}



/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// One-time GL state
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glClearColor(0.10f, 0.12f, 0.13f, 1.0f);

	// Load and bind textures once
	LoadSceneTextures();

	// --- MATERIALS (Phong) — these tags are used later via SetShaderMaterial(...) ---
	{
		OBJECT_MATERIAL m;

		// Plane: wood-like surface (subtle specular so highlights look natural)
		m.tag = "wood";
		m.ambientColor = glm::vec3(0.24f, 0.20f, 0.16f);
		m.ambientStrength = 0.25f;
		m.diffuseColor = glm::vec3(0.60f, 0.47f, 0.34f);
		m.specularColor = glm::vec3(0.15f, 0.15f, 0.15f);
		m.shininess = 16.0f;
		m_objectMaterials.push_back(m);

		// Metal parts (beams/cones/legs): crisper highlights
		m.tag = "metal";
		m.ambientColor = glm::vec3(0.25f);
		m.ambientStrength = 0.20f;
		m.diffuseColor = glm::vec3(0.72f);
		m.specularColor = glm::vec3(0.95f);
		m.shininess = 64.0f;
		m_objectMaterials.push_back(m);

		// Plastic sphere: neutral white, medium specular
		m.tag = "plastic";
		m.ambientColor = glm::vec3(0.20f);
		m.ambientStrength = 0.20f;
		m.diffuseColor = glm::vec3(0.95f);
		m.specularColor = glm::vec3(0.50f);
		m.shininess = 32.0f;
		m_objectMaterials.push_back(m);
	}

	// --- LIGHTS (two sources; second is warm tinted) ---
	if (m_pShaderManager)
	{
		// Tell the shader to use the custom lighting path
		m_pShaderManager->setBoolValue(g_UseLightingName, true); // "bUseLighting"

		// Key light (white) — like sun/window
		m_pShaderManager->setVec3Value("lightPos1", glm::vec3(3.0f, 5.0f, 5.0f));
		m_pShaderManager->setVec3Value("lightColor1", glm::vec3(1.0f, 1.0f, 1.0f));

		// Fill light (warm) — softens shadows, adds color
		m_pShaderManager->setVec3Value("lightPos2", glm::vec3(-4.0f, 3.0f, 2.0f));
		m_pShaderManager->setVec3Value("lightColor2", glm::vec3(1.0f, 0.9f, 0.7f));

		// Low global ambient to avoid pure black areas
		m_pShaderManager->setVec3Value("globalAmbient", glm::vec3(0.08f, 0.08f, 0.08f));
	}


	// Load each unique mesh once (safe subset—avoids torus/tapered-cylinder loaders
	// which can crash in some course packs).
	m_basicMeshes->LoadPlaneMesh();     // floor
	m_basicMeshes->LoadBoxMesh();       // seat/back/armrests
	m_basicMeshes->LoadCylinderMesh();  // legs
	m_basicMeshes->LoadSphereMesh();    // pillows (optional)
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// --- per-frame setup ---
	GLint vp[4] = { 0,0,0,0 };
	glGetIntegerv(GL_VIEWPORT, vp);
	if (vp[2] <= 0 || vp[3] <= 0) glViewport(0, 0, 1280, 720);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// camera/eye position (for Phong lighting on the floor)
	if (m_pShaderManager)
		m_pShaderManager->setVec3Value("viewPos", glm::vec3(0.0f, 4.0f, 10.0f));

	// --- helpers ---
	auto BindTex0 = [&](GLuint tex, float u = 1.0f, float v = 1.0f)
		{
			if (tex != 0) {
				glActiveTexture(GL_TEXTURE0);
				glBindTexture(GL_TEXTURE_2D, tex);
				if (m_pShaderManager) {
					m_pShaderManager->setIntValue(g_TextureValueName, 0);           // "objectTexture" -> unit 0
					m_pShaderManager->setIntValue(g_UseTextureName, 1);            // bUseTexture = true
					m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));     // if your shader supports it
				}
			}
			else {
				if (m_pShaderManager) m_pShaderManager->setIntValue(g_UseTextureName, 0);
				glBindTexture(GL_TEXTURE_2D, 0);
			}
		};

	auto DrawFabricBox = [&](const glm::vec3& scale, float rx, float ry, float rz, const glm::vec3& pos)
		{
			SetTransformations(scale, rx, ry, rz, pos);
			// complex object: prioritize texture; lighting off to avoid black if materials mismatch
			if (m_pShaderManager) m_pShaderManager->setBoolValue(g_UseLightingName, false);

			if (gTexFabric != 0) {
				SetShaderColor(1, 1, 1, 1);
				BindTex0(gTexFabric, 3.0f, 3.0f);
			}
			else {
				if (m_pShaderManager) m_pShaderManager->setIntValue(g_UseTextureName, 0);
				SetShaderColor(0.68f, 0.64f, 0.60f, 1.0f); // taupe fallback if fabric missing
			}
			m_basicMeshes->DrawBoxMesh();
		};

	auto DrawWoodLeg = [&](float x, float z)
		{
			glm::vec3 scale(0.22f, 0.70f, 0.22f);
			SetTransformations(scale, 90.0f, 0.0f, 0.0f, glm::vec3(x, 0.55f, z));
			if (m_pShaderManager) m_pShaderManager->setBoolValue(g_UseLightingName, false);

			if (gTexWood != 0) {
				SetShaderColor(1, 1, 1, 1);
				BindTex0(gTexWood, 1.5f, 1.0f);
			}
			else {
				if (m_pShaderManager) m_pShaderManager->setIntValue(g_UseTextureName, 0);
				SetShaderColor(0.30f, 0.22f, 0.16f, 1.0f); // wood-ish fallback
			}
			m_basicMeshes->DrawCylinderMesh();
		};

	// shared transform vars
	glm::vec3 scaleXYZ, positionXYZ;
	float Xrot = 0.0f, Yrot = 0.0f, Zrot = 0.0f;

	/************************ FLOOR (wood plane, LIT) ************************/
	scaleXYZ = glm::vec3(22.0f, 0.5f, 14.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
	Xrot = Yrot = Zrot = 0.0f;

	SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, positionXYZ);
	SetShaderColor(1, 1, 1, 1);
	SetShaderMaterial("wood");                              // safe if you added materials in PrepareScene
	if (m_pShaderManager) m_pShaderManager->setBoolValue(g_UseLightingName, true); // plane reflects light
	BindTex0(gTexWood, 4.0f, 4.0f);                         // nicely tiled wood
	m_basicMeshes->DrawPlaneMesh();
	/********************************************************************/

	/************************ COUCH PIECES (FABRIC) ************************/
	// seat
	DrawFabricBox(glm::vec3(6.8f, 0.6f, 2.7f), 0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 1.0f, 0.0f));
	// back
	DrawFabricBox(glm::vec3(6.8f, 2.1f, 0.55f), -5.0f, 0.0f, 0.0f, glm::vec3(0.0f, 2.25f, -1.45f));
	// armrests (L/R)
	DrawFabricBox(glm::vec3(0.65f, 1.7f, 2.7f), 0.0f, 0.0f, 0.0f, glm::vec3(-3.6f, 1.85f, 0.0f));
	DrawFabricBox(glm::vec3(0.65f, 1.7f, 2.7f), 0.0f, 0.0f, 0.0f, glm::vec3(3.6f, 1.85f, 0.0f));
	// chaise extension
	DrawFabricBox(glm::vec3(2.6f, 0.6f, 3.6f), 0.0f, 0.0f, 0.0f, glm::vec3(-2.1f, 1.0f, 0.55f));
	/************************************************************************/

	/************************ LEGS (WOOD) ************************/
	DrawWoodLeg(-2.9f, -1.1f);
	DrawWoodLeg(2.9f, -1.1f);
	DrawWoodLeg(-2.9f, 1.1f);
	DrawWoodLeg(2.9f, 1.1f);
	/****************************************************************/
}
